
const express = require("express");
const router = express.Router();
const { hello } = require("../controller/controller");

router.get("/test", hello);

module.exports = router;
