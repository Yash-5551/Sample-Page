
const express = require("express");
const app = express();

const connectDB = require("./db/connection");
const router = require("./router/route"); 

app.use("/", router);

const PORT = process.env.PORT || 8000;

connectDB().then(()=>{
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
});
